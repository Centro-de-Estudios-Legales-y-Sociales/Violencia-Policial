la carpeta data es accesible solo por FTP (para cambiar los json de datos)

el menu LazyBlocks tiene los graficos para poder modificar, por ejemplo, filtros (la parte html), no se recomienda tocarlo.