(function($) {
  $(".read-more").readmore({
    speed: 600,
    collapsedHeight: 120,
    heightMargin: 16,
    lessLink:
      '<a href="" class="read-more-btn "><i class="fas fa-chevron-up"></i>ver menos</a>',
    moreLink:
      '<a href="" class="read-more-btn"><i class="fas fa-chevron-down"></i>ver más</a>',
  });
  
})(jQuery);
