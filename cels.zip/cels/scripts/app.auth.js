'use strict';

angular.module('app.auth', ['satellizer'])
.config(function($authProvider) {

});
