'use strict';
angular.module('app.core', []);
